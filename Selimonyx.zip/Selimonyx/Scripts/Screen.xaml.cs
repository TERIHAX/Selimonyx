﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Net;
using System.IO.Compression;
using System.Windows.Forms;

namespace DesireRebornWPF
{
    /// <summary>
    /// Interaction logic for Screen.xaml
    /// </summary>
    public partial class Screen : Window
    {
        public Screen()
        {
            InitializeComponent();

            if (File.Exists("settings"))
            {
                File.Delete("settings");
            }

            Opacity = 0.9;
            Blur.Radius = 20;

            TimerEvents();
        }

        byte Red;
        byte Green;
        byte Blue;

        Timer TimerRed = new Timer
        {
            Enabled = true,
            Interval = 1
        };

        Timer TimerGreen = new Timer
        {
            Enabled = true,
            Interval = 1
        };

        Timer TimerBlue = new Timer
        {
            Enabled = true,
            Interval = 1
        };

        void TimerEvents()
        {
            TimerRed.Tick += delegate (object Sender, EventArgs E)
            {
                if (Blue >= 244)
                {
                    Red -= 6;
                    Icon.Foreground = new SolidColorBrush(Color.FromRgb(Red, Green, Blue));
                    if (Red <= 65)
                    {
                        TimerRed.Stop();
                        TimerGreen.Start();
                    }
                }

                if (Blue <= 65)
                {
                    Red += 6;
                    Icon.Foreground = new SolidColorBrush(Color.FromRgb(Red, Green, Blue));
                    if (Red >= 244)
                    {
                        TimerRed.Stop();
                        TimerGreen.Start();
                    }
                }
            };

            TimerGreen.Tick += delegate (object Sender, EventArgs E)
            {
                if (Red <= 65)
                {
                    Green += 6;
                    Icon.Foreground = new SolidColorBrush(Color.FromRgb(Red, Green, Blue));
                    if (Green >= 244)
                    {
                        TimerGreen.Stop();
                        TimerBlue.Start();
                    }
                }

                if (Red >= 244)
                {
                    Green -= 6;
                    Icon.Foreground = new SolidColorBrush(Color.FromRgb(Red, Green, Blue));
                    if (Green <= 65)
                    {
                        TimerGreen.Stop();
                        TimerBlue.Start();
                    }
                }
            };

            TimerBlue.Tick += delegate (object Sender, EventArgs E)
            {
                if (Green <= 65)
                {
                    Blue += 6;

                    // Your Controls
                    Icon.Foreground = new SolidColorBrush(Color.FromRgb(Red, Green, Blue));
                    if (Blue >= 244)
                    {
                        TimerBlue.Stop();
                        TimerRed.Start();
                    }
                }

                if (Green >= 244)
                {
                    Blue -= 6;

                    // Your Controls
                    Icon.Foreground = new SolidColorBrush(Color.FromRgb(Red, Green, Blue));

                    if (Blue <= 65)
                    {
                        TimerBlue.Stop();
                        TimerRed.Start();
                    }
                }
            };
        }

        private async void Window_Loaded(object sender, RoutedEventArgs e)
        {
            int I_ = 0;
            while (I_ < 20)
            {
                await Task.Delay(10);
                Blur.Radius -= 1;

                I_++; // Incrementation
            }

            for (; Opacity < 0.0; Opacity += 0.1)
            {
                await Task.Delay(15);
            }

            Opacity = 1;

            Library.ObjectMove(Main, Main.Margin, new Thickness(10, 10, 0, 0), 750);
            Library.ObjectMove(Top, Top.Margin, new Thickness(0, 0, 0, 194), 1000);

            await Task.Delay(750);

            ServicePointManager.Expect100Continue = true;
            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;

            await Task.Delay(500);
            using (WebClient Client = new WebClient())
            {
                // Directories/Folders
                if (!Directory.Exists("Bin")) // Imagine not having bin folder
                {
                    Client.DownloadFile("https://github.com/TERIHAX/DesireReborn/raw/main/Bin.zip", "Bin.zip");

                    ZipFile.ExtractToDirectory("./Bin.zip", Environment.CurrentDirectory);

                    if (Directory.Exists("Bin") && File.Exists("Bin.zip"))
                    {
                        File.Delete("Bin.zip");
                    }
                }

                Library.ObjectMove(Icon, Icon.Margin, new Thickness(147, 63, 0, 0), 750);

                if (!Directory.Exists("Scripts"))
                {
                    Directory.CreateDirectory("Scripts");
                }

                Library.ObjectMove(Icon, Icon.Margin, new Thickness(147, 70, 0, 0), 750);

                if (!Directory.Exists("WorkSpace"))
                {
                    Directory.CreateDirectory("WorkSpace");
                }

                Library.ObjectMove(Icon, Icon.Margin, new Thickness(147, 63, 0, 0), 750);

                if (!Directory.Exists("AutoExecute"))
                {
                    Directory.CreateDirectory("AutoExecute");
                }

                Library.ObjectMove(Icon, Icon.Margin, new Thickness(147, 70, 0, 0), 750);

                // Files
                // PuppyMilk
                if (!File.Exists("./Bin/Tools/Injector.exe"))
                {
                    Client.DownloadFile("https://github.com/TERIHAX/DesireReborn/raw/main/PuppyMilkV3.exe", "./Bin/Tools/Injector.exe");
                }

                Library.ObjectMove(Icon, Icon.Margin, new Thickness(147, 63, 0, 0), 750);

                // Discord RPC Dll
                if (!File.Exists("Discord-Rpc-w32.dll"))
                {
                    Client.DownloadFile("https://github.com/TERIHAX/DesireReborn/raw/main/discord-rpc-w32.dll", "Discord-Rpc-w32.dll");
                }

                Library.ObjectMove(Icon, Icon.Margin, new Thickness(147, 70, 0, 0), 750);

                // Avalon
                if (!File.Exists("ICSharpCode.AvalonEdit.dll"))
                {
                    Client.DownloadFile("https://github.com/TERIHAX/DesireReborn/raw/main/ICSharpCode.AvalonEdit.dll", "ICSharpCode.AvalonEdit.dll");
                }

                Library.ObjectMove(Icon, Icon.Margin, new Thickness(147, 63, 0, 0), 750);

                // DLL
                if (!File.Exists("DesireLBI.dll"))
                {
                    // Client.DownloadFile("https://github.com/TERIHAX/DesireReborn/blob/main/DLL/DesireLBI.dll", "DesireLBI.dll");
                }

                Library.ObjectMove(Icon, Icon.Margin, new Thickness(147, 70, 0, 0), 750);

                // APIs
                if (!Furk.IsInjected())
                {
                    Furk.DownloadDLL();
                }

                Library.ObjectMove(Icon, Icon.Margin, new Thickness(147, 63, 0, 0), 750);

                if (!Hecta.IsAPIAttached())
                {
                    if (File.Exists("Hecta.dll"))
                    {
                        File.Delete("Hecta.dll");
                    }

                    using (WebClient Web = new WebClient())
                    {
                        Web.DownloadFile("https://github.com/LilFrench21/HectaSploit/blob/main/Hecta.dll?raw=true", "Hecta.dll");
                    }
                }

                Library.ObjectMove(Icon, Icon.Margin, new Thickness(147, 70, 0, 0), 750);

                if (!EasyEx.NamedPipeExist("ocybedam"))
                {
                    if (EasyEx.CheckDllUpdate())
                    {
                        if (File.Exists("EasyXploits.dll"))
                        {
                            File.Delete("EasyXploits.dll");
                        }

                        EasyEx.DownloadDLL();
                    }
                }

                Library.ObjectMove(Icon, Icon.Margin, new Thickness(147, 63, 0, 0), 750);

                if (!Anemo.NamedPipeExist("AnemoPIPE"))
                {
                    if (Anemo.CheckDllUpdate())
                    {
                        if (File.Exists("Anemo.dll"))
                        {
                            File.Delete("Anemo.dll");
                        }

                        Anemo.DownloadDLL();
                    }
                }

                Library.ObjectMove(Icon, Icon.Margin, new Thickness(147, 70, 0, 0), 750);
            }

            Label.Text = "   Ready!";

            await Task.Delay(500);

            for (int I = 0; I < 20; I++)
            {
                await Task.Delay(50);
                Blur.Radius += 1;
            }

            for (; Opacity > 0.0; Opacity -= 0.1)
            {
                await Task.Delay(10);
            }

            Opacity = 0;

            Hide();
            WindowState = WindowState.Minimized;

            new MainWindow().Show();
        }

        private async void Close_Click(object sender, RoutedEventArgs e)
        {
            for (int I = 0; I < 20; I++)
            {
                await Task.Delay(50);
                Blur.Radius += 1;
            }

            for (; Opacity > 0.0; Opacity -= 0.1)
            {
                await Task.Delay(10);
            }

            Opacity = 0;
            Environment.Exit(0);
        }

        private void Drag(object sender, MouseButtonEventArgs e)
        {
            if (e.LeftButton == MouseButtonState.Pressed)
            {
                DragMove();
            }
        }
    }
}
