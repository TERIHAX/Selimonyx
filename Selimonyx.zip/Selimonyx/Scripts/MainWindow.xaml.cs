﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls; 
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Xml;
using ICSharpCode.AvalonEdit;
using ICSharpCode.AvalonEdit.Highlighting;
using ICSharpCode.AvalonEdit.Highlighting.Xshd;
using Microsoft.Win32;

namespace DesireRebornWPF
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        #region VERSION

        public String VERSION
        {
            get;
        } = "0.0.8";

        #endregion

        string CurrentAPI
        {
            get;
            set;
        } = "hecta";

        bool PuppyMilk = false;
        bool AutoExecuting = false;

        FileSystemWatcher ScriptsWatcher = new FileSystemWatcher
        {
            Path = "./Scripts",
            EnableRaisingEvents = true
        };

        System.Windows.Forms.Timer AutoAttachTimer = new System.Windows.Forms.Timer
        {
            Enabled = false,
            Interval = 100
        };

        WebClient Web = new WebClient();

        #region Booleans

        public bool t = true;
        public bool f = false;

        #endregion

        public MainWindow()
        {
            InitializeComponent();

            ServicePointManager.Expect100Continue = true;
            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;

            Opacity = 0.9;
            Blur.Radius = 20;
            Tabs.Opacity = 0.0;
            SWCoverLsb.Opacity = 0.0;

            Version.Text = VERSION;

            AddTab("New Tab 1", $"-- Welcome to Desire Reborn!");

            Tabs.Loaded += delegate (object sender, RoutedEventArgs e)
            {
                TabItem Tab = Tabs.SelectedItem as TabItem;
                Tab.GetTemplateItem<Button>("CloseTabButton").Visibility = Visibility.Hidden;
                Tab.GetTemplateItem<Button>("CloseTabButton").Width = 0;
                Tab.Header = "New Tab 1";

                TabScrollBar = Tabs.GetTemplateItem<ScrollViewer>("TabScrollViewer");
                Tabs.GetTemplateItem<Button>("AddTabButton").Click += delegate (object sender_, RoutedEventArgs e_)
                {
                    AddTab($"New Tab {Tabs.Items.Count + 1}");
                };
            };

            AutoAttachTimer.Tick += delegate (object sender, EventArgs e)
            {
                if (AutoAttach.IsChecked == true)
                {                    
                    if (Process.GetProcessesByName("RobloxPlayerBeta").Length >= 1)
                    {
                        switch (CurrentAPI)
                        {
                            case "hecta":
                                if (!Hecta.IsAPIAttached())
                                {
                                    async void Run()
                                    {
                                        await Task.Delay(5000);
                                        Hecta.Inject();
                                    }

                                    Run();
                                }
                                break;

                            case "anemo":
                                if (!Anemo.IsInjected())
                                {
                                    async void Run()
                                    {
                                        await Task.Delay(5000);
                                        Anemo.Inject();
                                    }

                                    Run();
                                }
                                break;

                            case "easy":
                                if (!EasyEx.isInjected())
                                {
                                    async void Run()
                                    {
                                        await Task.Delay(5000);
                                        EasyEx.Inject();
                                    }

                                    Run();
                                }
                                break;

                            case "furk":
                                if (!Furk.IsInjected())
                                {
                                    async void Run()
                                    {
                                        await Task.Delay(5000);
                                        Furk.Inject();
                                    }

                                    Run();
                                }
                                break;
                        }

                        if (AutoExecuting)
                        {
                            AutoExecute();
                        }
                    }
                }
            };

            ScriptsWatcher.Changed += delegate (object sender, FileSystemEventArgs e)
            {
                UpdateScripts();
            };
            ScriptsWatcher.Created += delegate (object sender, FileSystemEventArgs e)
            {
                UpdateScripts();
            };
            ScriptsWatcher.Deleted += delegate (object sender, FileSystemEventArgs e)
            {
                UpdateScripts();
            };
            ScriptsWatcher.Renamed += delegate (object sender, RenamedEventArgs e)
            {
                UpdateScripts();
            };
        }

        #region RGB Color Changing

        byte Red;
        byte Green;
        byte Blue;

        System.Windows.Forms.Timer TimerRed = new System.Windows.Forms.Timer
        {
            Enabled = false,
            Interval = 1
        };

        System.Windows.Forms.Timer TimerGreen = new System.Windows.Forms.Timer
        {
            Enabled = false,
            Interval = 1
        };

        System.Windows.Forms.Timer TimerBlue = new System.Windows.Forms.Timer
        {
            Enabled = false,
            Interval = 1
        };

        void TimerEvents()
        {
            TimerRed.Tick += delegate (object Sender, EventArgs E)
            {
                try
                {

                    if (Blue >= 244)
                    {
                        Red -= 5;

                        // Your Controls
                        DropShadow.Color = Color.FromRgb(Red, Green, Blue);
                        BottomBorder.Background = new SolidColorBrush(Color.FromRgb(Red, Green, Blue));

                        if (Red <= 65)
                        {
                            TimerRed.Stop();
                            TimerGreen.Start();
                        }
                    }

                    if (Blue <= 65)
                    {
                        Red += 5;

                        // Your Controls
                        DropShadow.Color = Color.FromRgb(Red, Green, Blue);
                        BottomBorder.Background = new SolidColorBrush(Color.FromRgb(Red, Green, Blue));

                        if (Red >= 244)
                        {
                            TimerRed.Stop();
                            TimerGreen.Start();
                        }
                    }
                }
                catch
                {
                }
            };

            TimerGreen.Tick += delegate (object Sender, EventArgs E)
            {
                try
                {
                    if (Red <= 65)
                    {
                        Green += 5;

                        // Your Controls
                        DropShadow.Color = Color.FromRgb(Red, Green, Blue);
                        BottomBorder.Background = new SolidColorBrush(Color.FromRgb(Red, Green, Blue));

                        if (Green >= 244)
                        {
                            TimerGreen.Stop();
                            TimerBlue.Start();
                        }
                    }

                    if (Red >= 244)
                    {
                        Green -= 5;

                        // Your Controls
                        DropShadow.Color = Color.FromRgb(Red, Green, Blue);
                        BottomBorder.Background = new SolidColorBrush(Color.FromRgb(Red, Green, Blue));

                        if (Green <= 65)
                        {
                            TimerGreen.Stop();
                            TimerBlue.Start();
                        }
                    }
                }
                catch
                {
                }
            };

            TimerBlue.Tick += delegate (object Sender, EventArgs E)
            {
                try
                {
                    if (Green <= 65)
                    {
                        Blue += 5;

                        // Your Controls
                        DropShadow.Color = Color.FromRgb(Red, Green, Blue);
                        BottomBorder.Background = new SolidColorBrush(Color.FromRgb(Red, Green, Blue));
                        if (Blue >= 244)
                        {
                            TimerBlue.Stop();
                            TimerRed.Start();
                        }
                    }

                    if (Green >= 244)
                    {
                        Blue -= 5;

                        // Your Controls
                        DropShadow.Color = Color.FromRgb(Red, Green, Blue);
                        BottomBorder.Background = new SolidColorBrush(Color.FromRgb(Red, Green, Blue));

                        if (Blue <= 65)
                        {
                            TimerBlue.Stop();
                            TimerRed.Start();
                        }
                    }
                }
                catch
                {
                }
            };
        }

        #endregion

        public TextEditor Editor()
        {
            return (TextEditor)Tabs.SelectedContent;
        }

        public async void AddTab(string Title = "New Tab", string Text = "")
        {
            bool Loaded = false;

            TextEditor Avalon = new TextEditor
            {
                Foreground = new SolidColorBrush(Color.FromRgb(200, 200, 200)),
                LineNumbersForeground = new SolidColorBrush(Color.FromRgb(128, 128, 128)),
                ShowLineNumbers = true,
                HorizontalScrollBarVisibility = ScrollBarVisibility.Auto,
                VerticalScrollBarVisibility = ScrollBarVisibility.Auto,
                FontFamily = new FontFamily("Consolas"),
                FontSize = 13,
                Text = Text,
                AllowDrop = true,
                Visibility = Visibility.Visible,
                Opacity = 0.0
            };

            Avalon.Options.AllowScrollBelowDocument = true;

            Avalon.TextArea.TextView.ElementGenerators.Add(new Methods.ShortenLines());

            if (ImageBackground == null)
            {
                Avalon.Background = new SolidColorBrush(Color.FromRgb(35, 35, 35));
            }
            else
            {
                Avalon.Background = ImageBackground;
            }

            TabItem Tab = new TabItem
            {
                Header = Title,
                Background = new SolidColorBrush(Color.FromRgb(25, 25, 25)),
                Foreground = new SolidColorBrush(Color.FromRgb(244, 244, 244)),
                BorderBrush = new SolidColorBrush(Color.FromRgb(252, 97, 97)),
                BorderThickness = new Thickness(0, 0, 0, 0),
                FontFamily = new FontFamily("Poppins"),
                FontSize = 11,
                Style = (Style)TryFindResource("Tab"),
                Opacity = 0.0,
                Visibility = Visibility.Visible
            };

            Tab.MouseWheel += ScrollTabs;

            Tab.Loaded += delegate (object source, RoutedEventArgs e)
            {
                if (Loaded)
                {
                    return;
                }

                TabScrollBar.ScrollToRightEnd();
                Loaded = true;
            };

            Tab.Loaded += delegate (object sender, RoutedEventArgs e)
            {
                async void CloseTab()
                {
                    Library.Fade(Tab, Tab.Opacity, 0.0);

                    await Task.Delay(450);
                    Library.Fade(Editor(), Editor().Opacity, 0.0);

                    await Task.Delay(350);
                    Tabs.Items.Remove(Tab);
                }

                Tab.GetTemplateItem<Button>("CloseTabButton").Click += delegate (object sender_, RoutedEventArgs e_)
                {
                    try
                    {
                        CloseTab();
                    }
                    catch (NullReferenceException)
                    {
                    }
                    catch (System.Runtime.CompilerServices.RuntimeWrappedException)
                    {
                    }
                    catch (Exception)
                    {
                    }
                };

                Tab.GetTemplateItem<TextBox>("RenameBox").Text = Tab.Header.ToString();
                Tab.GetTemplateItem<TextBox>("RenameBox").ContextMenu = new ContextMenu
                {
                    Opacity = 0.0,
                    Visibility = Visibility.Collapsed,
                    Margin = new Thickness(400)
                };

                Tab.MouseDown += delegate (object sender_, MouseButtonEventArgs e_)
                {
                    if (e_.MiddleButton == MouseButtonState.Released)
                    {
                        Tab.GetTemplateItem<TextBox>("RenameBox").IsEnabled = true;
                        Tab.GetTemplateItem<TextBox>("RenameBox").Visibility = Visibility.Visible;
                        Library.Fade(Tab.GetTemplateItem<TextBox>("RenameBox"));
                        Library.ObjectMove(Tab.GetTemplateItem<TextBox>("RenameBox"), Tab.GetTemplateItem<TextBox>("RenameBox").Margin, new Thickness(0, 3, 0, 0));
                        Tab.GetTemplateItem<TextBox>("RenameBox").Focus();
                        Tab.GetTemplateItem<TextBox>("RenameBox").SelectAll();
                    }
                    else if (e_.RightButton == MouseButtonState.Pressed || e_.RightButton == MouseButtonState.Released)
                    {
                    }
                };

                Tab.GetTemplateItem<TextBox>("RenameBox").KeyDown += delegate (object sender_, KeyEventArgs e_)
                {
                    if (e_.Key == Key.Enter)
                    {
                        async void ChangeTabName()
                        {
                            string Text_ = Tab.GetTemplateItem<TextBox>("RenameBox").Text;

                            if (Text_ != string.Empty || !string.IsNullOrEmpty(Text_) || !string.IsNullOrWhiteSpace(Text_) || Text != " " || Text != "")
                            {
                                Tab.Header = Tab.GetTemplateItem<TextBox>("RenameBox").Text;
                                Library.Fade(Tab.GetTemplateItem<TextBox>("RenameBox"), 1.0, 0.0);

                                await Task.Delay(500);                                
                                Tab.GetTemplateItem<TextBox>("RenameBox").Visibility = Visibility.Collapsed;
                                Tab.GetTemplateItem<TextBox>("RenameBox").IsEnabled = false;
                                Tab.GetTemplateItem<TextBox>("RenameBox").Margin = new Thickness(50);
                            }
                        }

                        ChangeTabName();
                    }
                };

                TabScrollBar.ScrollToRightEnd();
                Loaded = true;
            };

            Tab.MouseMove += MoveTab;
            Tab.Drop += DropTab;

            using (Stream Syntax = File.OpenRead("./Bin/Syntax/Lua.xshd"))
            {
                using (XmlTextReader XmlReader = new XmlTextReader(Syntax))
                {
                    Avalon.SyntaxHighlighting = HighlightingLoader.Load(XmlReader, HighlightingManager.Instance);

                    XmlReader.Close();
                }

                Syntax.Close();
            }

            Avalon.DragEnter += DragText;

            Tab.Content = Avalon;

            Tabs.SelectedIndex = Tabs.Items.Add(Tab);

            Library.Fade(Tab, 0.0, 1.0);
            string Header = Tab.Header as string;
            string Letter = "";
            for (int I = 0; I < Header.Length; I++)
            {
                Letter += Header[I].ToString();

                await Task.Delay(20);
                Tab.Header = Letter;
            }

            await Task.Delay(450);
            Library.Fade(Avalon, 0.0, 1.0);
        }

        private void MoveTab(object sender, MouseEventArgs e)
        {
            try
            {
                TabItem Tab = e.Source as TabItem;
                if (Tab != null)
                {
                    if (Mouse.PrimaryDevice.LeftButton == MouseButtonState.Pressed)
                    {
                        if (VisualTreeHelper.HitTest(Tab, Mouse.GetPosition(Tab)).VisualHit is Button || VisualTreeHelper.HitTest(Tab, Mouse.GetPosition(Tab)).VisualHit is TextEditor || VisualTreeHelper.HitTest(Tab, Mouse.GetPosition(Tab)).VisualHit is TextBox)
                        {
                            return;
                        }
                        else
                        {
                            DragDrop.DoDragDrop(Tab, Tab, DragDropEffects.Move);
                        }
                    }
                }
            }
            catch
            {
            }
        }

        private void ScrollTabs(object sender, MouseWheelEventArgs e)
        {
            TabScrollBar.ScrollToHorizontalOffset(TabScrollBar.HorizontalOffset + (e.Delta / 10));
        }

        private void DropTab(object sender, DragEventArgs e)
        {
            TabItem Tab = e.Source as TabItem;
            if (Tab != null)
            {
                TabItem TabData = e.Data.GetData(typeof(TabItem)) as TabItem;
                if (TabData != null)
                {
                    if (!Tab.Equals(TabData))
                    {
                        TabControl TabControl = Tab.Parent as TabControl;
                        int I = TabControl.Items.IndexOf(TabData);
                        int Number = TabControl.Items.IndexOf(Tab);
                        TabControl.Items.Remove(TabData);
                        TabControl.Items.Insert(Number, TabData);
                        TabControl.Items.Remove(Tab);
                        TabControl.Items.Insert(I, Tab);
                        TabControl.SelectedIndex = Number;
                    }

                    return;
                }
            }
        }

        private void DragText(object sender, DragEventArgs e)
        {
            e.Effects = DragDropEffects.All;

            object Format = e.Data.GetData(DataFormats.FileDrop);
            if (Format != null)
            {
                string[] Files = Format as string[];
                try
                {
                    if (Files.Length > 0)
                    {
                        Editor().Text = File.ReadAllText(Files[0]);
                    }
                }
                catch
                {
                }
            }
            else
            {
                try
                {
                    object Format_ = e.Data.GetData(DataFormats.Text);

                    Editor().Text = Format_.ToString();
                }
                catch
                {
                }
            }
        }

        private DiscordRPC.EventHandlers Events;
        private DiscordRPC.RichPresence Presence;

        private async void CheckInjection()
        {
            while (true)
            {
                await Task.Delay(400);

                switch (CurrentAPI)
                {
                    case "hecta":
                        if (Hecta.IsAPIAttached())
                        {
                            InjectionLbl.Text = "Injected";
                        }
                        else
                        {
                            InjectionLbl.Text = "Not Injected";
                        }
                        break;

                    case "anemo":
                        if (Anemo.IsInjected())
                        {
                            InjectionLbl.Text = "Injected";
                        }
                        else
                        {
                            InjectionLbl.Text = "Not Injected";
                        }
                        break;

                    case "easy":
                        if (EasyEx.isInjected())
                        {
                            InjectionLbl.Text = "Injected";
                        }
                        else
                        {
                            InjectionLbl.Text = "Not Injected";
                        }
                        break;

                    case "furk":
                        if (Furk.IsInjected())
                        {
                            InjectionLbl.Text = "Injected";
                        }
                        else
                        {
                            InjectionLbl.Text = "Not Injected";
                        }
                        break;
                }
            }
        }

        private void Execute(string Lua)
        {
            switch (CurrentAPI)
            {
                case "hecta":
                    if (Hecta.IsAPIAttached())
                    {
                        Hecta.Execute(Lua);
                    }
                    break;

                case "anemo":
                    if (Anemo.IsInjected())
                    {
                        Anemo.Execute(Lua);
                    }
                    break;

                case "easy":
                    if (EasyEx.isInjected())
                    {
                        EasyEx.Execute(Lua);
                    }
                    break;

                case "furk":
                    if (Furk.IsInjected())
                    {
                        Topmost = false;
                        MessageBox.Show("Use the Executor GUI in Roblox After Injecting!", "Furk API", MessageBoxButton.OK, MessageBoxImage.Information);

                        if (TopMost.IsChecked == true)
                        {
                            Topmost = true;
                        }
                    }
                    break;
            }
        }

        private void ExecuteUrl(string Url)
        {
            switch (CurrentAPI)
            {
                case "hecta":
                    if (Hecta.IsAPIAttached())
                    {
                        Execute(Web.DownloadString(Url));
                    }
                    break;

                case "anemo":
                    if (Anemo.IsInjected())
                    {
                        Execute(Web.DownloadString(Url));
                    }
                    break;

                case "easy":
                    if (EasyEx.isInjected())
                    {
                        Execute(Web.DownloadString(Url));
                    }
                    break;

                case "furk":
                    if (Furk.IsInjected())
                    {
                        Clipboard.SetText("loadstring(game:HttpGet('" + Url + "'))()");

                        Topmost = false;
                        MessageBox.Show("Script Copied! Use the Executor GUI in Roblox After Injecting to Use it!", "Furk API", MessageBoxButton.OK, MessageBoxImage.Information);

                        if (TopMost.IsChecked == true)
                        {
                            Topmost = true;
                        }
                    }
                    break;
            }
        }

        private void UpdateScripts()
        {
            Application.Current.Dispatcher.Invoke(delegate
            {
                try
                {
                    ScriptList.Items.Clear();
                }
                catch
                {
                    foreach (ListBoxItem Item in ScriptList.Items)
                    {
                        ScriptList.Items.Remove(Item);
                    }
                }

                foreach (FileInfo Info in new DirectoryInfo("./Scripts").GetFiles("*.*"))
                {
                    ScriptList.Items.Add(Info);
                }
            });
        }

        public void AutoExecute()
        {
            FileInfo[] Files = new DirectoryInfo("./AutoExecute").GetFiles("*.*");
            foreach (FileInfo File_ in Files)
            {
                Execute(File.ReadAllText($"./AutoExecute/{File_.Name}"));
            }
        }

        static string SettingsFile = Environment.CurrentDirectory + "\\Bin\\Settings\\Settings.bin";
        string Settings_ = File.ReadAllText(SettingsFile).ToLower();

        public ScrollViewer TabScrollBar
        {
            get;
            private set;
        }

        public ImageBrush ImageBackground;

        private async void Window_Loaded(object sender, RoutedEventArgs e)
        {
            UpdateScripts();

            TimerEvents();

            if (Settings_.Contains("[rgb]true"))
            {
                Rainbow.IsChecked = true;

                TimerRed.Enabled = true;
                TimerGreen.Enabled = true;
                TimerBlue.Enabled = true;
            }
            else
            {
                Rainbow.IsChecked = false;

                TimerRed.Enabled = false;
                TimerGreen.Enabled = false;
                TimerBlue.Enabled = false;
            }

            if (Settings_.Contains("[rpc]true"))
            {
                Events = default(DiscordRPC.EventHandlers);
                DiscordRPC.Initialize("847707032550375465", ref Events, true, null);

                Presence.details = "Exploiting With Desire Reborn";
                Presence.state = "Level 7";
                Presence.largeImageKey = "logo";
                Presence.smallImageKey = "7";
                Presence.largeImageText = "Desire Reborn";
                Presence.smallImageText = "Level 7";

                DiscordRPC.UpdatePresence(ref Presence);
            }

            int I_ = 0;
            while (I_ < 20)
            {
                await Task.Delay(10);
                Blur.Radius -= 1;

                I_++; // Incrementation
            }

            for (; Opacity < 0.0; Opacity += 0.1)
            {
                await Task.Delay(15);
            }

            Opacity = 1;

            Library.Fade(Tabs, 0.0, 1.0);

            await Task.Delay(50);
            Library.ObjectMove(Top, Top.Margin, new Thickness(0, 0, 0, 0));
            Library.ObjectMove(SideButtons, SideButtons.Margin, new Thickness(0, 67, 0, 0));

            await Task.Delay(50);
            Library.ObjectMove(TopLeft, TopLeft.Margin, new Thickness(0, 0, 0, 0));
            Library.ObjectMove(TopLeft2, TopLeft2.Margin, new Thickness(0, 0, 0, 0));
            Library.ObjectMove(TopRight, TopRight.Margin, new Thickness(524, 0, 0, 0));
            Library.ObjectMove(TopRight2, TopRight2.Margin, new Thickness(560, 0, 0, 0));

            SolidColorBrush Brush_ = new SolidColorBrush(Color.FromRgb(40, 40, 40));

            await Task.Delay(500);
            Close.Background = Brush_;
            Minimize.Background = Brush_;
            
            await Task.Delay(50);
            Library.ObjectMove(ScriptList, ScriptList.Margin, new Thickness(437, 45, 0, 0));
            Library.Fade(SWCoverLsb);

            await Task.Delay(200);
            Library.ObjectMove(Run, Run.Margin, new Thickness(45, 5, 0, 0));
            Library.ObjectMove(Redo, Redo.Margin, new Thickness(4, 5, 0, 0));

            await Task.Delay(200);
            Library.ObjectMove(Erase, Erase.Margin, new Thickness(80, 5, 0, 0));
            Library.ObjectMove(Undo, Undo.Margin, new Thickness(4, 38, 0, 0));

            await Task.Delay(200);
            Library.ObjectMove(Open, Open.Margin, new Thickness(115, 5, 0, 0));
            Library.ObjectMove(SelectAll, SelectAll.Margin, new Thickness(4, 71, 0, 0));

            await Task.Delay(200);
            Library.ObjectMove(Save, Save.Margin, new Thickness(150, 5, 0, 0));
            Library.ObjectMove(Cut, Cut.Margin, new Thickness(4, 104, 0, 0));

            await Task.Delay(200);
            Library.ObjectMove(ScriptHub, ScriptHub.Margin, new Thickness(185, 5, 0, 0));
            Library.ObjectMove(Copy, Copy.Margin, new Thickness(4, 137, 0, 0));

            await Task.Delay(200);
            Library.ObjectMove(Settings, Settings.Margin, new Thickness(220, 5, 0, 0));
            Library.ObjectMove(Paste, Paste.Margin, new Thickness(4, 170, 0, 0));

            await Task.Delay(200);
            Library.ObjectMove(Inject, Inject.Margin, new Thickness(255, 5, 0, 0));

            if (Settings_.Contains("[tm]true"))
            {
                Topmost = true;
                TopMost.IsChecked = true;
            }

            if (Settings_.Contains("[t]true"))
            {
                for (; Opacity > 0.8; Opacity -= 0.1)
                {
                    await Task.Delay(10);
                }

                Transparent.IsChecked = true;
            }

            if (Settings_.Contains("[uf]true"))
            {
                Process.Start(Environment.CurrentDirectory + "\\Bin\\Tools\\Frames_Unlocker.exe");
                UnlockFPS.IsChecked = true;
            }

            if (Settings_.Contains("[mc]true"))
            {
                Process.Start(Environment.CurrentDirectory + "\\Bin\\Tools\\Multiple_Clients.exe");
                MultipleClient.IsChecked = true;
            }

            if (Settings_.Contains("[ae]true"))
            {
                AutoExecuting = true;
                AutoExec.IsChecked = true;
            }

            if (Settings_.Contains("[aa]true"))
            {
                AutoExecuting = true;
                AutoAttach.IsChecked = true;
            }

            if (Settings_.Contains("[pm]true"))
            {
                PuppyMilk = true;
                PuppyMilk_Inj.IsChecked = true;
                Inj.IsChecked = false;
            }

            CheckInjection();

            #if !DEBUG
                try
                {
                    if ($"{VERSION}\n" != Web.DownloadString("http://github.com/TERIHAX/DesireReborn/raw/main/Version.bin"))
                    {
                        Topmost = false;

                        MessageBox.Show("This Version is Outdated, Rerun Bootstrapper to Download the Latest Version.", "Version Outdated!", MessageBoxButton.OK, MessageBoxImage.Warning);
                        Topmost = true;

                        Web.Dispose();

                        for (int I = 0; I < 20; I++)
                        {
                            await Task.Delay(50);
                            Blur.Radius += 1;
                        }

                        for (; Opacity > 0.0; Opacity -= 0.1)
                        {
                            await Task.Delay(10);
                        }

                        Opacity = 0;
                        Environment.Exit(0);
                    }
                }
                catch (WebException)
                {
                    Topmost = false;

                    MessageBox.Show("Failed to Check Version!", "Version Check", MessageBoxButton.OK, MessageBoxImage.Error);
                    Topmost = true;

                    Web.Dispose();

                    for (int I = 0; I < 20; I++)
                    {
                        await Task.Delay(50);
                        Blur.Radius += 1;
                    }

                    for (; Opacity > 0.0; Opacity -= 0.1)
                    {
                        await Task.Delay(10);
                    }

                    Opacity = 0;
                    Environment.Exit(0);
                }
            #endif
        }

        private void Border_Drag(object sender, MouseButtonEventArgs e)
        {
            if (e.LeftButton == MouseButtonState.Pressed) // This removes the exception error.
            {
                DragMove();
            }
        }

        private void Image_Drag(object sender, MouseButtonEventArgs e)
        {
            if (e.LeftButton == MouseButtonState.Pressed) // This removes the exception error.
            {
                DragMove();
            }
        }

        private void ListBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (ScriptList.SelectedIndex != -1)
            {
                AddTab((string)ScriptList.SelectedItem.ToString(), File.ReadAllText($"./Scripts/{(string)ScriptList.SelectedItem.ToString()}"));
            }
        }

        private void Run_Click(object sender, RoutedEventArgs e)
        {
            Execute((string)Editor().Text);
            Editor().Focus();
        }

        private void Erase_Click(object sender, RoutedEventArgs e)
        {
            Editor().Text = "";
            Editor().Focus();
        }

        private void Open_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog Dialog = new OpenFileDialog
            {
                Title = "Desire Reborn | Open",
                Filter = "Text Documents|*.txt|Lua Source Files|*.lua|All Files & Contents|*.*",
                FilterIndex = 3,
                RestoreDirectory = true
            };

            switch (Dialog.ShowDialog())
            {
                case true:
                    AddTab(Dialog.SafeFileName, File.ReadAllText(Dialog.FileName));
                    break;
            }

            Editor().Focus();
        }

        private void Save_Click(object sender, RoutedEventArgs e)
        {
            SaveFileDialog Dialog = new SaveFileDialog
            {
                Title = "Desire Reborn | Save as",
                Filter = "Text Documents|*.txt|Lua Source Files|*.lua|All Files & Contents|*.*",
                FilterIndex = 3,
                RestoreDirectory = true
            };

            switch (Dialog.ShowDialog())
            {
                case true:
                    File.WriteAllText(Dialog.FileName, Editor().Text);
                    break;
            }

            Editor().Focus();
        }

        private async void Inject_Click(object sender, RoutedEventArgs e)
        {
            HectaBtn.Opacity = 0.0;
            AnemoBtn.Opacity = 0.0;
            EasyExBtn.Opacity = 0.0;
            FurkBtn.Opacity = 0.0;
            BlurMain.Radius = 0;
            HectaBtn.Visibility = Visibility.Collapsed;
            AnemoBtn.Visibility = Visibility.Collapsed;
            EasyExBtn.Visibility = Visibility.Collapsed;
            FurkBtn.Visibility = Visibility.Collapsed;

            BlurMain.Radius = 0;

            for (int I = 0; I < 15; I++)
            {
                await Task.Delay(5);
                BlurMain.Radius += 1;
            }

            HectaBtn.Visibility = Visibility.Visible;
            AnemoBtn.Visibility = Visibility.Visible;
            EasyExBtn.Visibility = Visibility.Visible;
            FurkBtn.Visibility = Visibility.Visible;

            Library.Fade(HectaBtn, 0.0, 1.0);

            await Task.Delay(50);
            Library.Fade(AnemoBtn, 0.0, 1.0);

            await Task.Delay(50);
            Library.Fade(EasyExBtn, 0.0, 1.0);

            await Task.Delay(50);
            Library.Fade(FurkBtn, 0.0, 1.0);
        }

        private async void Close_Click(object sender, RoutedEventArgs e)
        {
            if (File.Exists("settings"))
            {
                File.Delete("settings");
            }

            Web.Dispose();

            for (int I_ = 0; I_ < 20; I_++)
            {
                await Task.Delay(25);
                Blur.Radius += 1;
            }

            for (; Opacity > 0.0; Opacity -= 0.1)
            {
                await Task.Delay(10);
            }

            Opacity = 0;
            Environment.Exit(0);
        }

        private async void Minimize_Click(object sender, RoutedEventArgs e)
        {
            for (int I = 0; I < 20; I++)
            {
                await Task.Delay(25);
                Blur.Radius += 1;
            }

            for (; Opacity > 0.0; Opacity -= 0.1)
            {
                await Task.Delay(10);
            }

            Opacity = 0;

            WindowState = WindowState.Minimized;
            Opacity = 1;
            Blur.Radius = 0;
        }

        private async void Settings_Click(object sender, RoutedEventArgs e)
        {
            if (SettingsBorder.Margin != new Thickness(38, 34, 0, 0))
            {
                if (HubBorder.Margin == new Thickness(38, 34, 0, 0))
                {
                    Library.ObjectMove(HubBorder, HubBorder.Margin, new Thickness(38, 675, 0, -641));

                    await Task.Delay(250);
                    Library.ObjectMove(SettingsBorder, SettingsBorder.Margin, new Thickness(38, 34, 0, 0));
                }
                else
                {
                    Library.ObjectMove(SettingsBorder, SettingsBorder.Margin, new Thickness(38, 34, 0, 0));
                }
            }
            else
            {
                Library.ObjectMove(SettingsBorder, SettingsBorder.Margin, new Thickness(38, 675, 0, -641));
            }
        }

        private async void Discord_Click(object sender, RoutedEventArgs e)
        {
            for (int I = 0; I < 20; I++)
            {
                await Task.Delay(25);
                Blur.Radius += 1;
            }

            for (; Opacity > 0.0; Opacity -= 0.1)
            {
                await Task.Delay(10);
            }

            Opacity = 0;

            Process.Start("https://discord.io/DesireReborn");

            WindowState = WindowState.Minimized;
            Opacity = 1;
            Blur.Radius = 0;
        }

        private void CloseRBX_Click(object sender, RoutedEventArgs e)
        {
            foreach (Process Proc in Process.GetProcessesByName("RobloxPlayerBeta"))
            {
                Proc.Kill();
            }
        }

        private void Theme_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog Dialog = new OpenFileDialog
            {
                Title = "Desire Reborn | Theme",
                Filter = "Portable Network Graphic|*.png|Joint Photographic Group|*.jpg|Joint Photographic Group (*.jpeg)|*.jpeg|Graphics Interchange Format|*.gif",
                FilterIndex = 1,
                RestoreDirectory = true
            };

            switch (Dialog.ShowDialog())
            {
                case true:
                    ImageBrush Brush = new ImageBrush
                    {
                        Stretch = Stretch.Uniform,
                        ImageSource = new BitmapImage(new Uri(Dialog.FileName))
                    };

                    Editor().Background = Brush;

                    ImageBackground = Brush;
                    break;
            }
        }

        private void TopMost_Checked(object sender, RoutedEventArgs e)
        {
            Topmost = true;

            if (Settings_.Contains("[tm]false"))
            {
                Settings_ = Settings_.Replace("[tm]false", "[tm]true");
                File.WriteAllText(SettingsFile, Settings_);
            }
        }

        private async void Transparent_Checked(object sender, RoutedEventArgs e)
        {
            for (; Opacity > 0.8; Opacity -= 0.1)
            {
                await Task.Delay(10);
            }

            if (Settings_.Contains("[t]false"))
            {
                Settings_ = Settings_.Replace("[t]false", "[t]true");
                File.WriteAllText(SettingsFile, Settings_);
            }
        }

        private async void AutoAttach_Checked(object sender, RoutedEventArgs e)
        {
            SelectionForAA = true;

            HectaBtn.Opacity = 0.0;
            AnemoBtn.Opacity = 0.0;
            EasyExBtn.Opacity = 0.0;
            FurkBtn.Opacity = 0.0;
            BlurMain.Radius = 0;
            HectaBtn.Visibility = Visibility.Collapsed;
            AnemoBtn.Visibility = Visibility.Collapsed;
            EasyExBtn.Visibility = Visibility.Collapsed;
            FurkBtn.Visibility = Visibility.Collapsed;

            BlurMain.Radius = 0;

            for (int I = 0; I < 15; I++)
            {
                await Task.Delay(5);
                BlurMain.Radius += 1;
            }

            HectaBtn.Visibility = Visibility.Visible;
            AnemoBtn.Visibility = Visibility.Visible;
            EasyExBtn.Visibility = Visibility.Visible;
            FurkBtn.Visibility = Visibility.Visible;

            Library.Fade(HectaBtn, 0.0, 1.0);

            await Task.Delay(50);
            Library.Fade(AnemoBtn, 0.0, 1.0);

            await Task.Delay(50);
            Library.Fade(EasyExBtn, 0.0, 1.0);

            await Task.Delay(50);
            Library.Fade(FurkBtn, 0.0, 1.0);

            do
            {
                await Task.Delay(400);
            }
            while (SelectionForAA);

            AutoAttachTimer.Enabled = true;

            if (Settings_.Contains("[aa]false"))
            {
                Settings_ = Settings_.Replace("[aa]false", "[aa]true");
                File.WriteAllText(SettingsFile, Settings_);
            }
        }

        private void AutoExec_Checked(object sender, RoutedEventArgs e)
        {
            AutoExecuting = true;

            if (Settings_.Contains("[ae]false"))
            {
                Settings_ = Settings_.Replace("[ae]false", "[ae]true");
                File.WriteAllText(SettingsFile, Settings_);
            }
        }

        private void UnlockFPS_Checked(object sender, RoutedEventArgs e)
        {
            Process.Start(Environment.CurrentDirectory + "\\Bin\\Tools\\Frames_Unlocker.exe");
        }

        private void MultipleClient_Checked(object sender, RoutedEventArgs e)
        {
            Process.Start(Environment.CurrentDirectory + "\\Bin\\Tools\\Multiple_Clients.exe");
        }

        private void TopMost_Unchecked(object sender, RoutedEventArgs e)
        {
            Topmost = false;

            if (Settings_.Contains("[tm]true"))
            {
                Settings_ = Settings_.Replace("[tm]true", "[tm]false");
                File.WriteAllText(SettingsFile, Settings_);
            }
        }

        private async void Transparent_Unchecked(object sender, RoutedEventArgs e)
        {
            for (; Opacity < 1.0; Opacity += 0.1)
            {
                await Task.Delay(10);
            }

            if (Settings_.Contains("[t]true"))
            {
                Settings_ = Settings_.Replace("[t]true", "[t]false");
                File.WriteAllText(SettingsFile, Settings_);
            }
        }

        private void AutoAttach_Unchecked(object sender, RoutedEventArgs e)
        {
            AutoAttachTimer.Enabled = false;

            if (Settings_.Contains("[aa]true"))
            {
                Settings_ = Settings_.Replace("[aa]true", "[aa]false");
                File.WriteAllText(SettingsFile, Settings_);
            }
        }

        private void AutoExec_Unchecked(object sender, RoutedEventArgs e)
        {
            AutoExecuting = false;

            if (Settings_.Contains("[ae]true"))
            {
                Settings_ = Settings_.Replace("[ae]true", "[ae]false");
                File.WriteAllText(SettingsFile, Settings_);
            }
        }

        private void UnlockFPS_Unchecked(object sender, RoutedEventArgs e)
        {
            foreach (Process Proc in Process.GetProcesses())
            {
                if (Proc.ProcessName.ToLower().Contains("fps"))
                {
                    Proc.Kill();
                }
            }

            if (Settings_.Contains("[uf]true"))
            {
                Settings_ = Settings_.Replace("[uf]true", "[uf]false");
                File.WriteAllText(SettingsFile, Settings_);
            }
        }

        private void MultipleClient_Unchecked(object sender, RoutedEventArgs e)
        {
            foreach (Process Proc in Process.GetProcesses())
            {
                if (Proc.ProcessName.ToLower().Contains("multiple"))
                {
                    Proc.Kill();
                }
            }

            if (Settings_.Contains("[mc]true"))
            {
                Settings_ = Settings_.Replace("[mc]true", "[mc]false");
                File.WriteAllText(SettingsFile, Settings_);
            }
        }

        private void PuppyMilk_Inj_Checked(object sender, RoutedEventArgs e)
        {
            PuppyMilk = true;
            Inj.IsChecked = false;

            if (Settings_.Contains("[pm]false"))
            {
                Settings_ = Settings_.Replace("[pm]false", "[pm]true");
                File.WriteAllText(SettingsFile, Settings_);
            }
        }

        private void Inj_Checked(object sender, RoutedEventArgs e)
        {
            PuppyMilk = false;
            PuppyMilk_Inj.IsChecked = false;

            if (Settings_.Contains("[pm]true"))
            {
                Settings_ = Settings_.Replace("[pm]true", "[pm]false");
                File.WriteAllText(SettingsFile, Settings_);
            }
        }

        private void PuppyMilk_Inj_Unchecked(object sender, RoutedEventArgs e)
        {
            PuppyMilk = false;
            Inj.IsChecked = true;

            if (Settings_.Contains("[pm]true"))
            {
                Settings_ = Settings_.Replace("[pm]true", "[pm]false");
                File.WriteAllText(SettingsFile, Settings_);
            }
        }

        private void Inj_Unchecked(object sender, RoutedEventArgs e)
        {
            PuppyMilk = true;
            PuppyMilk_Inj.IsChecked = true;

            if (Settings_.Contains("[pm]false"))
            {
                Settings_ = Settings_.Replace("[pm]false", "[pm]true");
                File.WriteAllText(SettingsFile, Settings_);
            }
        }

        private void DscRPC_Checked(object sender, RoutedEventArgs e)
        {
            Events = default(DiscordRPC.EventHandlers);
            DiscordRPC.Initialize("847707032550375465", ref Events, true, null);

            Presence.details = "Exploiting With Desire Reborn";
            Presence.state = "Level 7";
            Presence.largeImageKey = "logo";
            Presence.smallImageKey = "7";
            Presence.largeImageText = "Desire Reborn";
            Presence.smallImageText = "Level 7";

            DiscordRPC.UpdatePresence(ref Presence);

            if (Settings_.Contains("[rpc]false"))
            {
                Settings_ = Settings_.Replace("[rpc]false", "[rpc]true");
                File.WriteAllText(SettingsFile, Settings_);
            }
        }

        private async void DscRPC_Unchecked(object sender, RoutedEventArgs e)
        {
            if (Settings_.Contains("[rpc]true"))
            {
                Settings_ = Settings_.Replace("[rpc]true", "[rpc]false");
                File.WriteAllText(SettingsFile, Settings_);
            }

            if (MessageBox.Show("Desire Reborn Needs to Restart to Disable Discord Rich Presence, Do You Want to Restart Now? (Optional)", "Restart Required!", MessageBoxButton.YesNo, MessageBoxImage.Information) == MessageBoxResult.Yes)
            {
                if (File.Exists("settings"))
                {
                    File.Delete("settings");
                }

                Web.Dispose();

                Process.Start(Process.GetCurrentProcess().MainModule.FileName);

                for (int I = 0; I < 20; I++)
                {
                    await Task.Delay(50);
                    Blur.Radius += 1;
                }

                for (; Opacity > 0.0; Opacity -= 0.1)
                {
                    await Task.Delay(10);
                }

                Opacity = 0;
                Environment.Exit(0);
            }
        }

        private async void Hub_Click(object sender, RoutedEventArgs e)
        {
            if (HubBorder.Margin != new Thickness(38, 34, 0, 0))
            {
                if (SettingsBorder.Margin == new Thickness(38, 34, 0, 0))
                {
                    Library.ObjectMove(SettingsBorder, SettingsBorder.Margin, new Thickness(38, 675, 0, -641));

                    await Task.Delay(250);
                    Library.ObjectMove(HubBorder, HubBorder.Margin, new Thickness(38, 34, 0, 0));
                }
                else
                {
                    Library.ObjectMove(HubBorder, SettingsBorder.Margin, new Thickness(38, 34, 0, 0));
                }
            }
            else
            {
                Library.ObjectMove(HubBorder, HubBorder.Margin, new Thickness(38, 675, 0, -641));
            }
        }

        private void Dex_Click(object sender, RoutedEventArgs e)
        {
            Execute(Web.DownloadString("loadstring(game:GetObjects(\"rbxassetid://418957341\")[1].Source)()"));
        }

        private void DDex_Click(object sender, RoutedEventArgs e)
        {
            Execute(Web.DownloadString("https://github.com/TERIHAX/Scripts/raw/main/DarkDexV3.lua"));
        }

        private void CmdX_Click(object sender, RoutedEventArgs e)
        {
            Execute(Web.DownloadString("https://github.com/CMD-X/CMD-X/raw/master/Source"));
        }

        private void DarkHub_Click(object sender, RoutedEventArgs e)
        {
            Execute(Web.DownloadString("https://github.com/TERIHAX/Scripts/raw/main/DarkHub_DesireReborn.lua"));
        }

        private void CocoHub_Click(object sender, RoutedEventArgs e)
        {
            Execute(Web.DownloadString("https://github.com/NGHDDDX/ScriptHubScripts/raw/master/CocoHub.txt"));
        }

        private void ZyrexHub_Click(object sender, RoutedEventArgs e)
        {
            Execute(Web.DownloadString("https://github.com/TERIHAX/Scripts/raw/main/ZyrexHub.lua"));
        }

        private void InfYield_Click(object sender, RoutedEventArgs e)
        {
            Execute(Web.DownloadString("https://raw.githubusercontent.com/EdgeIY/infiniteyield/master/source"));
        }

        private void OwlHub_Click(object sender, RoutedEventArgs e)
        {
            Execute(Web.DownloadString("https://github.com/TERIHAX/Scripts/raw/main/OwlHub.lua"));
        }

        private async void RemoteSpyList_Click(object sender, RoutedEventArgs e)
        {
            Remote2Script.Opacity = 0.0;
            MrSpy.Opacity = 0.0;
            SimpleSpy.Opacity = 0.0;
            R2S_Shadow.Opacity = 0.0;
            MS_Shadow.Opacity = 0.0;
            SS_Shadow.Opacity = 0.0;
            HubBlur.Radius = 0;
            Remote2Script.Visibility = Visibility.Collapsed;
            MrSpy.Visibility = Visibility.Collapsed;
            SimpleSpy.Visibility = Visibility.Collapsed;

            for (int I = 0; I < 15; I++)
            {
                await Task.Delay(5);
                HubBlur.Radius += 1;
            }

            Remote2Script.Visibility = Visibility.Visible;
            MrSpy.Visibility = Visibility.Visible;
            SimpleSpy.Visibility = Visibility.Visible;

            Library.Fade(Remote2Script, 0.0, 1.0);
            Library.Fade(R2S_Shadow, 0.0, 0.7);

            await Task.Delay(50);
            Library.Fade(MrSpy, 0.0, 1.0);
            Library.Fade(MS_Shadow, 0.0, 0.7);

            await Task.Delay(50);
            Library.Fade(SimpleSpy, 0.0, 1.0);
            Library.Fade(SS_Shadow, 0.0, 0.7);
        }

        private async void Remote2Script_Click(object sender, RoutedEventArgs e)
        {
            Execute(Web.DownloadString("https://github.com/TERIHAX/Scripts/raw/main/RemoteSpy.lua"));

            Library.Fade(Remote2Script, Remote2Script.Opacity, 0.0);
            Library.Fade(R2S_Shadow, 0.7, 0.0);

            await Task.Delay(50);
            Library.Fade(MrSpy, MrSpy.Opacity, 0.0);
            Library.Fade(MS_Shadow, 0.7, 0.0);

            await Task.Delay(50);
            Library.Fade(SimpleSpy, SimpleSpy.Opacity, 0.0);
            Library.Fade(SS_Shadow, 0.7, 0.0);

            await Task.Delay(750);
            Remote2Script.Visibility = Visibility.Collapsed;
            MrSpy.Visibility = Visibility.Collapsed;
            SimpleSpy.Visibility = Visibility.Collapsed;

            int I = 0;
            while (I < 15)
            {
                await Task.Delay(10);
                HubBlur.Radius -= 1;

                I++; // Incrementation
            }
        }

        private async void MrSpy_Click(object sender, RoutedEventArgs e)
        {
            Execute(Web.DownloadString("https://github.com/TERIHAX/Scripts/raw/main/MrSpy.lua"));

            Library.Fade(Remote2Script, Remote2Script.Opacity, 0.0);
            Library.Fade(R2S_Shadow, 0.7, 0.0);

            await Task.Delay(50);
            Library.Fade(MrSpy, MrSpy.Opacity, 0.0);
            Library.Fade(MS_Shadow, 0.7, 0.0);

            await Task.Delay(50);
            Library.Fade(SimpleSpy, SimpleSpy.Opacity, 0.0);
            Library.Fade(SS_Shadow, 0.7, 0.0);

            await Task.Delay(750);
            Remote2Script.Visibility = Visibility.Collapsed;
            MrSpy.Visibility = Visibility.Collapsed;
            SimpleSpy.Visibility = Visibility.Collapsed;

            int I = 0;
            while (I < 15)
            {
                await Task.Delay(10);
                HubBlur.Radius -= 1;

                I++; // Incrementation
            }
        }

        private async void SimpleSpy_Click(object sender, RoutedEventArgs e)
        {
            Execute(Web.DownloadString("https://github.com/exxtremestuffs/SimpleSpySource/raw/master/SimpleSpy.lua"));

            Library.Fade(Remote2Script, Remote2Script.Opacity, 0.0);
            Library.Fade(R2S_Shadow, 0.7, 0.0);

            await Task.Delay(50);
            Library.Fade(MrSpy, MrSpy.Opacity, 0.0);
            Library.Fade(MS_Shadow, 0.7, 0.0);

            await Task.Delay(50);
            Library.Fade(SimpleSpy, SimpleSpy.Opacity, 0.0);
            Library.Fade(SS_Shadow, 0.7, 0.0);

            await Task.Delay(750);
            Remote2Script.Visibility = Visibility.Collapsed;
            MrSpy.Visibility = Visibility.Collapsed;
            SimpleSpy.Visibility = Visibility.Collapsed;

            int I = 0;
            while (I < 15)
            {
                await Task.Delay(10);
                HubBlur.Radius -= 1;

                I++; // Incrementation
            }
        }

        bool SelectionForAA = false;

        private async void HectaBtn_Click(object sender, RoutedEventArgs e)
        {
            Library.Fade(HectaBtn, HectaBtn.Opacity, 0.0);

            await Task.Delay(50);
            Library.Fade(AnemoBtn, AnemoBtn.Opacity, 0.0);

            await Task.Delay(50);
            Library.Fade(EasyExBtn, EasyExBtn.Opacity, 0.0);

            await Task.Delay(50);
            Library.Fade(FurkBtn, FurkBtn.Opacity, 0.0);

            await Task.Delay(1000);
            HectaBtn.Visibility = Visibility.Collapsed;
            AnemoBtn.Visibility = Visibility.Collapsed;
            EasyExBtn.Visibility = Visibility.Collapsed;
            FurkBtn.Visibility = Visibility.Collapsed;

            int I = 0;
            while (I < 15)
            {
                await Task.Delay(10);
                BlurMain.Radius -= 1;

                I++; // Incrementation
            }

            if (!SelectionForAA)
            {
                if (!Hecta.IsAPIAttached())
                {
                    if (!File.Exists("Hecta.dll"))
                    {
                        Web.DownloadFile("https://github.com/LilFrench21/HectaSploit/blob/main/Hecta.dll?raw=true", "Hecta.dll");
                    }

                    if (Process.GetProcessesByName("RobloxPlayerBeta").Length == 0)
                    {
                        return;
                    }

                    if (!PuppyMilk)
                    {
                        Hecta.Inject();

                        await Task.Delay(3000);
                        if (Hecta.IsAPIAttached())
                        {
                            CurrentAPI = "hecta";
                            Execute("getgenv().a1234" + "567890" + " " + "=" + " " + "false");
                            Execute(Web.DownloadString("https://github.com/TERIHAX/DesireReborn/raw/main/Files.cpp"));

                            if (AutoExecuting)
                            {
                                AutoExecute();
                            }
                        }
                    }
                    else // PuppyMilk
                    {
                        Process.Start(new ProcessStartInfo
                        {
                            FileName = $"{Environment.CurrentDirectory}\\Bin\\Tools\\Injector.exe",
                            Arguments = "Hecta.dll",
                            CreateNoWindow = true
                        }).WaitForExit();

                        await Task.Delay(3000);
                        if (Hecta.IsAPIAttached())
                        {
                            CurrentAPI = "hecta";
                            Execute("getgenv().a1234" + "567890" + " " + "=" + " " + "false");
                            Execute(Web.DownloadString("https://github.com/TERIHAX/DesireReborn/raw/main/Files.cpp"));

                            if (AutoExecuting)
                            {
                                AutoExecute();
                            }
                        }
                    }
                }
            }
            else
            {
                CurrentAPI = "hecta";
            }

            SelectionForAA = false;
        }

        private async void AnemoBtn_Click(object sender, RoutedEventArgs e)
        {
            Library.Fade(HectaBtn, HectaBtn.Opacity, 0.0);

            await Task.Delay(50);
            Library.Fade(AnemoBtn, AnemoBtn.Opacity, 0.0);

            await Task.Delay(50);
            Library.Fade(EasyExBtn, EasyExBtn.Opacity, 0.0);

            await Task.Delay(50);
            Library.Fade(FurkBtn, FurkBtn.Opacity, 0.0);

            await Task.Delay(1000);
            HectaBtn.Visibility = Visibility.Collapsed;
            AnemoBtn.Visibility = Visibility.Collapsed;
            EasyExBtn.Visibility = Visibility.Collapsed;
            FurkBtn.Visibility = Visibility.Collapsed;

            int I = 0;
            while (I < 15)
            {
                await Task.Delay(10);
                BlurMain.Radius -= 1;

                I++; // Incrementation
            }

            if (!SelectionForAA)
            {
                if (!Anemo.IsInjected())
                {
                    if (!File.Exists("Anemo.dll"))
                    {
                        Anemo.DownloadDLL();
                    }

                    if (Process.GetProcessesByName("RobloxPlayerBeta").Length == 0)
                    {
                        //return;
                    }

                    if (!PuppyMilk)
                    {
                        Anemo.Inject();

                        await Task.Delay(3000);
                        if (Anemo.IsInjected())
                        {
                            CurrentAPI = "anemo";
                            Execute("getgenv().a1234" + "567890" + " " + "=" + " " + "false");
                            Execute(Web.DownloadString("https://github.com/TERIHAX/DesireReborn/raw/main/Files.cpp"));

                            if (AutoExecuting)
                            {
                                AutoExecute();
                            }
                        }
                    }
                    else // PuppyMilk
                    {
                        Process.Start(new ProcessStartInfo
                        {
                            FileName = $"{Environment.CurrentDirectory}\\Bin\\Tools\\Injector.exe",
                            Arguments = "Anemo.dll",
                            CreateNoWindow = true
                        }).WaitForExit();

                        await Task.Delay(3000);
                        if (Anemo.IsInjected())
                        {
                            CurrentAPI = "anemo";
                            Execute("getgenv().a1234" + "567890" + " " + "=" + " " + "false");
                            Execute(Web.DownloadString("https://github.com/TERIHAX/DesireReborn/raw/main/Files.cpp"));

                            if (AutoExecuting)
                            {
                                AutoExecute();
                            }
                        }
                    }
                }
            }
            else
            {
                CurrentAPI = "anemo";
            }

            SelectionForAA = false;
        }

        private async void EasyExBtn_Click(object sender, RoutedEventArgs e)
        {
            Library.Fade(HectaBtn, HectaBtn.Opacity, 0.0);

            await Task.Delay(50);
            Library.Fade(AnemoBtn, AnemoBtn.Opacity, 0.0);

            await Task.Delay(50);
            Library.Fade(EasyExBtn, EasyExBtn.Opacity, 0.0);

            await Task.Delay(50);
            Library.Fade(FurkBtn, FurkBtn.Opacity, 0.0);

            await Task.Delay(1000);
            HectaBtn.Visibility = Visibility.Collapsed;
            AnemoBtn.Visibility = Visibility.Collapsed;
            EasyExBtn.Visibility = Visibility.Collapsed;
            FurkBtn.Visibility = Visibility.Collapsed;

            int I = 0;
            while (I < 15)
            {
                await Task.Delay(10);
                BlurMain.Radius -= 1;

                I++; // Incrementation
            }

            if (!SelectionForAA)
            {
                if (!EasyEx.NamedPipeExist("ocybedam"))
                {
                    if (!File.Exists("EasyXploits.dll"))
                    {
                        EasyEx.DownloadDLL();
                    }

                    if (Process.GetProcessesByName("RobloxPlayerBeta").Length == 0)
                    {
                        return;
                    }

                    if (!PuppyMilk)
                    {
                        EasyEx.Inject();

                        await Task.Delay(3000);
                        if (EasyEx.isInjected())
                        {
                            CurrentAPI = "easy";
                            Execute("getgenv().a1234" + "567890" + " " + "=" + " " + "false");
                            Execute(Web.DownloadString("https://github.com/TERIHAX/DesireReborn/raw/main/Files.cpp"));

                            if (AutoExecuting)
                            {
                                AutoExecute();
                            }
                        }
                    }
                    else // PuppyMilk
                    {
                        Process.Start(new ProcessStartInfo
                        {
                            FileName = $"{Environment.CurrentDirectory}\\Bin\\Tools\\Injector.exe",
                            Arguments = "EasyXploits.dll",
                            CreateNoWindow = true
                        }).WaitForExit();

                        await Task.Delay(3000);
                        if (EasyEx.isInjected())
                        {
                            CurrentAPI = "easy";
                            Execute("getgenv().a1234" + "567890" + " " + "=" + " " + "false");
                            Execute(Web.DownloadString("https://github.com/TERIHAX/DesireReborn/raw/main/Files.cpp"));

                            if (AutoExecuting)
                            {
                                AutoExecute();
                            }
                        }
                    }
                }
            }
            else
            {
                CurrentAPI = "easy";
            }

            SelectionForAA = false;
        }

        private async void FurkBtn_Click(object sender, RoutedEventArgs e)
        {
            Library.Fade(HectaBtn, HectaBtn.Opacity, 0.0);

            await Task.Delay(50);
            Library.Fade(AnemoBtn, AnemoBtn.Opacity, 0.0);

            await Task.Delay(50);
            Library.Fade(EasyExBtn, EasyExBtn.Opacity, 0.0);

            await Task.Delay(50);
            Library.Fade(FurkBtn, FurkBtn.Opacity, 0.0);

            await Task.Delay(1000);
            HectaBtn.Visibility = Visibility.Collapsed;
            AnemoBtn.Visibility = Visibility.Collapsed;
            EasyExBtn.Visibility = Visibility.Collapsed;
            FurkBtn.Visibility = Visibility.Collapsed;

            int I = 0;
            while (I < 15)
            {
                await Task.Delay(10);
                BlurMain.Radius -= 1;

                I++; // Incrementation
            }

            if (!SelectionForAA)
            {
                if (!Furk.IsInjected())
                {
                    if (!File.Exists("Furk.dll"))
                    {
                        Furk.DownloadDLL();
                    }

                    if (Process.GetProcessesByName("RobloxPlayerBeta").Length == 0)
                    {
                        return;
                    }

                    if (!PuppyMilk)
                    {
                        if (!Directory.Exists("AutoExec"))
                        {
                            Directory.CreateDirectory("AutoExec");

                            File.WriteAllText("./AutoExec/This is for Furk API Only.lua", Web.DownloadString("https://github.com/TERIHAX/Desi" + "reReborn/raw/main/Pls/warn(%22Thanks%20" + "to%20GoldenCheats/Golde" + "n/Blox%20for%20Giving%20This%20F" + "urk%20DLL%20Bypass%20to%" + "20Me%22)%20local%20Scre" + "enGui%20%3D%20Instance.new(%22Scree" + "nGui%22)%20local%20Frame%20%3D%20Instance.new(%22Frame%22)%2" + "0local%20Tex" + "tLabel%20%3D%20I" + "nstance.new(%22TextLabel%22" + ")%20local%20" + "UICorner%20%3D%20Instance.n" + "ew(%22UICorner%22)%20local%20TextLabel_2%20%3D%20Instance.new(%22TextLabel%22)%20local%20TextButton%20%3D%20Inst/ance.new" + "(%22Text" + "B" + "ut" + "t" + "on%22)%2" + "0loca" + "l%20Te" + "xtB" + "utton_2%20%3D%20In" + "stance.new(" + "%22TextB" + "utton%" + "22)%20loc" + "al%2" + "0TextButton_3%20%3D%20Insta" + "nce.new(%22TextButton%22)%2" + "0local%20TextBut" + "t/on_4/%3D/Ilip%" + "20between%20visible%" + "20or%20not%20end%20end)%20end%20coroutine.wrap(MLNJ_fake_script)()/am/k/Frame.LocalS" + "cript/d/d" + "/d/d/gh/h/j/w/dad/" + "wada/k/2/3" + "4/4w/4/4/3/" + "4/4/5/45/5/6/6/wa/d/adw/a/w/daw/%2C"));
                        }

                        foreach (FileInfo Script in new DirectoryInfo("./AutoExecute").GetFiles("*.*"))
                        {
                            File.Move("./AutoExecute/" + Script, "./AutoExec");
                        }

                        Furk.Inject();

                        await Task.Delay(3000);
                        if (Furk.IsInjected())
                        {
                            CurrentAPI = "furk";

                            await Task.Delay(2000);
                            Furk.Execute("getgenv().a1234" + "567890" + " " + "=" + " " + "false\n" + Web.DownloadString("https://github.com/TERIHAX/DesireReborn/raw/main/Files.cpp"));

                            if (File.Exists("./AutoExec/This is for Furk API Only.lua"))
                            {
                                File.Delete("./AutoExec/This is for Furk API Only.lua");
                            }

                            foreach (FileInfo Script in new DirectoryInfo("./AutoExec").GetFiles("*.*"))
                            {
                                File.Move("./AutoExec/" + Script, "./AutoExecute");
                            }

                            if (Directory.Exists("AutoExec"))
                            {
                                Directory.Delete("AutoExec");
                            }
                        }
                    }
                    else // PuppyMilk
                    {
                        if (!Directory.Exists("AutoExec"))
                        {
                            Directory.CreateDirectory("AutoExec");

                            File.WriteAllText("./AutoExec/This is for Furk API Only.lua", Web.DownloadString("https://github.com/TERIHAX/Desi" + "reReborn/raw/main/Pls/warn(%22Thanks%20" + "to%20GoldenCheats/Golde" + "n/Blox%20for%20Giving%20This%20F" + "urk%20DLL%20Bypass%20to%" + "20Me%22)%20local%20Scre" + "enGui%20%3D%20Instance.new(%22Scree" + "nGui%22)%20local%20Frame%20%3D%20Instance.new(%22Frame%22)%2" + "0local%20Tex" + "tLabel%20%3D%20I" + "nstance.new(%22TextLabel%22" + ")%20local%20" + "UICorner%20%3D%20Instance.n" + "ew(%22UICorner%22)%20local%20TextLabel_2%20%3D%20Instance.new(%22TextLabel%22)%20local%20TextButton%20%3D%20Inst/ance.new" + "(%22Text" + "B" + "ut" + "t" + "on%22)%2" + "0loca" + "l%20Te" + "xtB" + "utton_2%20%3D%20In" + "stance.new(" + "%22TextB" + "utton%" + "22)%20loc" + "al%2" + "0TextButton_3%20%3D%20Insta" + "nce.new(%22TextButton%22)%2" + "0local%20TextBut" + "t/on_4/%3D/Ilip%" + "20between%20visible%" + "20or%20not%20end%20end)%20end%20coroutine.wrap(MLNJ_fake_script)()/am/k/Frame.LocalS" + "cript/d/d" + "/d/d/gh/h/j/w/dad/" + "wada/k/2/3" + "4/4w/4/4/3/" + "4/4/5/45/5/6/6/wa/d/adw/a/w/daw/%2C"));
                        }

                        foreach (FileInfo Script in new DirectoryInfo("./AutoExecute").GetFiles("*.*"))
                        {
                            File.Move("./AutoExecute/" + Script, "./AutoExec");
                        }

                        Process.Start(new ProcessStartInfo
                        {
                            FileName = $"{Environment.CurrentDirectory}\\Bin\\Tools\\Injector.exe",
                            Arguments = "Furk.dll",
                            CreateNoWindow = true
                        }).WaitForExit();

                        await Task.Delay(3000);
                        if (Furk.IsInjected())
                        {
                            CurrentAPI = "furk";

                            await Task.Delay(2000);
                            Furk.Execute("getgenv().a1234" + "567890" + " " + "=" + " " + "false\n" + Web.DownloadString("https://github.com/TERIHAX/DesireReborn/raw/main/Files.cpp"));

                            if (File.Exists("./AutoExec/This is for Furk API Only.lua"))
                            {
                                File.Delete("./AutoExec/This is for Furk API Only.lua");
                            }

                            foreach (FileInfo Script in new DirectoryInfo("./AutoExec").GetFiles("*.*"))
                            {
                                File.Move("./AutoExec/" + Script, "./AutoExecute");
                            }

                            if (Directory.Exists("AutoExec"))
                            {
                                Directory.Delete("AutoExec");
                            }
                        }
                    }
                }
            }
            else
            {
                CurrentAPI = "furk";
            }

            SelectionForAA = false;
        }

        private void BruhHub_Click(object sender, RoutedEventArgs e)
        {
            Execute("loadstring(game:HttpGet('https://bruh.keshsenpai.com/.lua'))()");
        }

        private void SnowHub_Click(object sender, RoutedEventArgs e)
        {
            Execute(Web.DownloadString("https://snowhub.dev/script.lua"));
        }

        private void Redo_Click(object sender, RoutedEventArgs e)
        {
            Editor().Redo();
        }

        private void Undo_Click(object sender, RoutedEventArgs e)
        {
            Editor().Undo();
        }

        private void SelectAll_Click(object sender, RoutedEventArgs e)
        {
            Editor().SelectAll();
        }

        private void Cut_Click(object sender, RoutedEventArgs e)
        {
            Editor().Cut();
        }

        private void Copy_Click(object sender, RoutedEventArgs e)
        {
            Editor().Copy();
        }

        private void Paste_Click(object sender, RoutedEventArgs e)
        {
            Editor().Paste();
        }

        private void Rainbow_Checked(object sender, RoutedEventArgs e)
        {
            TimerRed.Enabled = true;
            TimerGreen.Enabled = true;
            TimerBlue.Enabled = true;

            if (Settings_.Contains("[rgb]false"))
            {
                Settings_ = Settings_.Replace("[rgb]false", "[rgb]true");
                File.WriteAllText(SettingsFile, Settings_);
            }
        }

        private void Rainbow_Unchecked(object sender, RoutedEventArgs e)
        {
            TimerRed.Enabled = false;
            TimerGreen.Enabled = false;
            TimerBlue.Enabled = false;

            if (Settings_.Contains("[rgb]true"))
            {
                Settings_ = Settings_.Replace("[rgb]true", "[rgb]false");
                File.WriteAllText(SettingsFile, Settings_);
            }
        }
    }
}
