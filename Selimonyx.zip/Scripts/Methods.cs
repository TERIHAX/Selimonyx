﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using ICSharpCode.AvalonEdit.Document;
using ICSharpCode.AvalonEdit.Rendering;

namespace DesireRebornWPF
{
    public static class Methods
    {
        public static T GetTemplateItem<T>(this Control Element, string Name)
        {
            return Element.Template.FindName(Name, (FrameworkElement)Element) is T Name_ ? Name_ : default(T);
        }

		public class ShortenLines : VisualLineElementGenerator
		{
			string Shorten = " ...";

			public override int GetFirstInterestedOffset(int StartingOffSet)
			{
				DocumentLine Line = CurrentContext.VisualLine.LastDocumentLine;

				if (Line.Length > 300)
				{
					int OffSetLength = Line.Offset + 300 - Shorten.Length;
					if (StartingOffSet <= OffSetLength)
					{
						return OffSetLength;
					}
				}

				return -1;
			}

			public override VisualLineElement ConstructElement(int OffSet)
			{
				return new FormattedTextElement(Shorten, CurrentContext.VisualLine.LastDocumentLine.EndOffset - OffSet);
			}
		}
	}
}
